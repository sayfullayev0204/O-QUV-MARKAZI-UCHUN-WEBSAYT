# Create your views here.
from django.shortcuts import render
from django.views.generic import ListView, DetailView, UpdateView, DeleteView,CreateView
from django.urls import reverse_lazy
from .models import Article





class ArticleListView(ListView):
    model = Article
    template_name = 'article_list.html'

class ArticleDetailView(DetailView):
    model = Article
    template_name = 'article_detail.html'

    def get(self, request, *args, **kwargs):
        print("ArticleDetailView is called!")
        return super().get(request, *args, **kwargs)


class ArticleUpdateView(UpdateView):
    model = Article
    fields = ('nomi', 'ustoz','start','narx','malumot')
    template_name = 'article_edit.html'

class ArticleDeleteView(DeleteView):
    model = Article
    template_name = 'article_delete.html'  # corrected typo in the template name
    success_url = reverse_lazy('article_list')

class ArticleListView(ListView):
    model = Article
    template_name = 'article_list.html'  

class ArticleCreateView(CreateView):
    model=Article
    template_name='article_new.html'
    fields = ['nomi', 'ustoz','start', 'narx','malumot']
