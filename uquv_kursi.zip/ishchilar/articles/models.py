from django.db import models
from django.contrib.auth import get_user_model 
from django.db import models
from django.urls import reverse

class Article(models.Model):
    nomi = models.CharField(max_length=255)
    ustoz = models.CharField(max_length=200, blank=True)
    start=models.DateField()
    narx = models.IntegerField()
    malumot = models.TextField() 


    def __str__(self):
        return self.name

    def get_absolute_url(self):
        return reverse('article_detail', args=[str(self.id)])
# Create your models here.
